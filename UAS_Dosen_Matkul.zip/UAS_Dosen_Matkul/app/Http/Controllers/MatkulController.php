<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Matkul;

class MatkulController extends Controller
{
    public function index(Request $request)
    {
        $acceptHeader = $request->header('Accept');

        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $Matkuls = Matkul::OrderBy("id", "DESC")->paginate(10);

            if ($acceptHeader === 'application/json') {
                return response()->json($Matkuls->items('data'), 200);
            } else {
                $xml = new \SimpleXMLElement('<Matkuls/>');
                foreach ($Matkuls->items('data') as $item) {
                    $xmlItem = $xml->addChild('matkul');
                    $xmlItem->addChild('id', $item->id);
                    $xmlItem->addChild('nama', $item->nama);
                    $xmlItem->addChild('created_at', $item->created_at);
                    $xmlItem->addChild('updated_at', $item->updated_at);
                }
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
    }

    public function show(Request $request, $matkulId)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $matkul = Matkul::find($matkulId);

            if (!$matkul) {
                abort(404);
            }
        
            if ($acceptHeader === 'application/json') {
                return response()->json($matkul, 200);
            } else {
                $xml = new \SimpleXMLElement('<matkul/>');
                $xml->addChild('id', $matkul->id);
                $xml->addChild('nama', $matkul->nama);
                $xml->addChild('created_at', $matkul->created_at);
                $xml->addChild('updated_at', $matkul->updated_at);
                return $xml->asXML();
            }
            
        } else {
            return response('Not Acceptable!', 406);
        }
    }

    public function store(Request $request)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {

            $input = $request->all();
            $matkul = Matkul::create($input);

            if ($acceptHeader === 'application/json') {
                return response()->json($matkul, 200);
            } else {
                $xml = new \SimpleXMLElement('<matkul/>');
                $xml->addChild('id', $matkul->id);
                $xml->addChild('nama', $matkul->nama);
                $xml->addChild('created_at', $matkul->created_at);
                $xml->addChild('updated_at', $matkul->updated_at);
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
    }

    public function update(Request $request, $matkulId)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $input = $request->all();

            $matkul = Matkul::find($matkulId);

            if (!$matkul) {
                abort(404);
            }

            $matkul->fill($input);
            $matkul->save();

            if ($acceptHeader === 'application/json') {
                return response()->json($matkul, 200);
            } else {
                $xml = new \SimpleXMLElement('<matkul/>');
                $xml->addChild('id', $matkul->id);
                $xml->addChild('matkulname', $matkul->matkulname);
                $xml->addChild('password', $matkul->password);
                $xml->addChild('nama', $matkul->nama);
                $xml->addChild('created_at', $matkul->created_at);
                $xml->addChild('updated_at', $matkul->updated_at);
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
        
    }

    public function destroy(Request $request, $matkulId)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $matkul = Matkul::find($matkulId);

            if (!$matkul) {
                abort(404);
            }

            $matkul->delete();

            if ($acceptHeader === 'application/json') {
                $message = ['message' => 'deleted successfully', 'matkulId' => $matkulId];
                return response()->json($message, 200);
            } else {
                $xml = new \SimpleXMLElement('<res/>');
                $xml->addChild('message', 'deleted successfully');
                $xml->addChild('matkulId', $matkulId);
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
        
    }

}
