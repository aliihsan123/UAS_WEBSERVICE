<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dosen;

class DosenController extends Controller
{
    public function index(Request $request)
    {
        $acceptHeader = $request->header('Accept');

        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $Dosens = Dosen::OrderBy("id", "DESC")->paginate(10);

            if ($acceptHeader === 'application/json') {
                return response()->json($Dosens->items('data'), 200);
            } else {
                $xml = new \SimpleXMLElement('<Dosens/>');
                foreach ($Dosens->items('data') as $item) {
                    $xmlItem = $xml->addChild('matkul');
                    $xmlItem->addChild('id', $item->id);
                    $xmlItem->addChild('nama', $item->nama);
                    $xmlItem->addChild('matkul_id', $item->matkul_id);
                    $xmlItem->addChild('created_at', $item->created_at);
                    $xmlItem->addChild('updated_at', $item->updated_at);
                }
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
    }

    public function show(Request $request, $dosenId)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $dosen = Dosen::find($dosenId);

            if (!$dosen) {
                abort(404);
            }
        
            if ($acceptHeader === 'application/json') {
                return response()->json($dosen, 200);
            } else {
                $xml = new \SimpleXMLElement('<dosen/>');
                $xml->addChild('id', $dosen->id);
                $xml->addChild('nama', $dosen->nama);
                $xml->addChild('matkul_id', $dosen->matkul_id);
                $xml->addChild('created_at', $dosen->created_at);
                $xml->addChild('updated_at', $dosen->updated_at);
                return $xml->asXML();
            }
            
        } else {
            return response('Not Acceptable!', 406);
        }
    }

    public function store(Request $request)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {

            $input = $request->all();
            $dosen = Dosen::create($input);

            if ($acceptHeader === 'application/json') {
                return response()->json($dosen, 200);
            } else {
                $xml = new \SimpleXMLElement('<dosen/>');
                $xml->addChild('id', $dosen->id);
                $xml->addChild('nama', $dosen->nama);
                $xml->addChild('created_at', $dosen->created_at);
                $xml->addChild('updated_at', $dosen->updated_at);
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
    }

    public function update(Request $request, $dosenId)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $input = $request->all();

            $dosen = Dosen::find($dosenId);

            if (!$dosen) {
                abort(404);
            }

            $dosen->fill($input);
            $dosen->save();

            if ($acceptHeader === 'application/json') {
                return response()->json($dosen, 200);
            } else {
                $xml = new \SimpleXMLElement('<dosen/>');
                $xml->addChild('id', $dosen->id);
                $xml->addChild('nama', $dosen->nama);
                $xml->addChild('matkul_id', $dosen->matkul_id);
                $xml->addChild('created_at', $dosen->created_at);
                $xml->addChild('updated_at', $dosen->updated_at);
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
        
    }

    public function destroy(Request $request, $dosenId)
    {
        $acceptHeader = $request->header('Accept');
        
        if ($acceptHeader === 'application/json' || $acceptHeader === 'application/xml') {
            $dosen = Dosen::find($dosenId);

            if (!$dosen) {
                abort(404);
            }

            $dosen->delete();

            if ($acceptHeader === 'application/json') {
                $message = ['message' => 'deleted successfully', 'dosenId' => $dosenId];
                return response()->json($message, 200);
            } else {
                $xml = new \SimpleXMLElement('<res/>');
                $xml->addChild('message', 'deleted successfully');
                $xml->addChild('dosenId', $dosenId);
                return $xml->asXML();
            }
        } else {
            return response('Not Acceptable!', 406);
        }
        
    }

}
