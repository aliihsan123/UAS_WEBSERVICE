<?php

use Illuminate\Support\Facades\Route;

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

// authentication
$router->group(['prefix' => 'auth'], function() use ($router) {
    // Matches "/api/register
    $router->post('/register', 'AuthController@register');
    $router->post('/login', 'AuthController@login');
});

// Post
// $router->group(['middleware' => 'auth'], function() use ($router) {
    $router->get ('/posts', 'PostsController@index');   
    $router->post ('/posts', 'PostsController@store');   
    $router->get ('/post/{id}', 'PostsController@show');   
    $router->delete ('/post/{id}', 'PostsController@destroy');   
    $router->put ('/post/{id}', 'PostsController@update');   
Route::group(['middleware' => ['auth']], function ($router) {
});

$router->get('/matkuls', 'MatkulController@index');
$router->get('/matkuls/{matkulId}', 'MatkulController@show');
$router->post('/matkuls', 'MatkulController@store');
$router->put('/matkuls/{matkulId}', 'MatkulController@update');
$router->delete('/matkuls/{matkulId}', 'MatkulController@destroy');

$router->get('/dosens', 'DosenController@index');
$router->get('/dosens/{dosenId}', 'DosenController@show');
$router->post('/dosens', 'DosenController@store');
$router->put('/dosens/{dosenId}', 'DosenController@update');
$router->delete('/dosens/{dosenId}', 'DosenController@destroy');